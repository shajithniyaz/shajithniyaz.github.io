# CISM Self-Paced Quiz

A simple, self-paced CISM question practice app built from the supplied **CISM Review Questions, Answers & Explanations Manual, 10th Edition (ISACA)** PDF.

## Files

- `index.html` — quiz UI and all interaction logic.
- `questions.json` — separate question/answer/justification data source.

## Run on a computer

From this folder:

```bash
python3 -m http.server 8000
```

Then open:

`http://localhost:8000/`

The page will fetch `questions.json` automatically.

## Open directly / iPhone

If the browser blocks `fetch()` for local `file://` pages, open `index.html` anyway and tap **Load questions.json**. Select the supplied `questions.json` file. The app will then work from the browser without a web server.

## Included features

- Four CISM domains as modules, with the domain weights shown in the manual.
- Self-paced one-question-at-a-time practice.
- Immediate correct/incorrect feedback.
- Source justification shown after answering.
- Previous/next navigation.
- Question number navigator.
- Search.
- Filters for unanswered, incorrect, bookmarked and mastered questions.
- Module practice, all-question, weak-area, bookmarked/review and unanswered modes.
- Bookmarks.
- Confidence tracking: low / medium / high.
- Personal notes per question.
- Local browser persistence.
- Progress dashboard and accuracy.
- Export/import progress backup.
- Keyboard shortcuts: `1–4`, arrows, `B`.
- Separate JSON data source so the UI can be reused with a corrected/expanded question bank later.

## Data quality note

The uploaded PDF is a scanned document. The question bank was OCR-extracted from the scanned pages. The JSON therefore includes a coverage report in `meta.coverage`, and a small number of questions could not be reliably parsed. For authoritative wording, compare questionable OCR text against the original PDF.
